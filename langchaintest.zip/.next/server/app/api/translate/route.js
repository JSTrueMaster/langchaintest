"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "app/api/translate/route";
exports.ids = ["app/api/translate/route"];
exports.modules = {

/***/ "@aws-sdk/client-s3":
/*!*************************************!*\
  !*** external "@aws-sdk/client-s3" ***!
  \*************************************/
/***/ ((module) => {

module.exports = require("@aws-sdk/client-s3");

/***/ }),

/***/ "next/dist/compiled/next-server/app-route.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/app-route.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/app-route.runtime.dev.js");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ "node:fs":
/*!**************************!*\
  !*** external "node:fs" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("node:fs");

/***/ }),

/***/ "node:stream":
/*!******************************!*\
  !*** external "node:stream" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("node:stream");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "punycode":
/*!***************************!*\
  !*** external "punycode" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("punycode");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ "worker_threads":
/*!*********************************!*\
  !*** external "worker_threads" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("worker_threads");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ "(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Ftranslate%2Froute&page=%2Fapi%2Ftranslate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Ftranslate%2Froute.js&appDir=E%3A%5CProjects%5Ctest%5Clangchain%5Clangchaintest%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=E%3A%5CProjects%5Ctest%5Clangchain%5Clangchaintest&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!":
/*!*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Ftranslate%2Froute&page=%2Fapi%2Ftranslate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Ftranslate%2Froute.js&appDir=E%3A%5CProjects%5Ctest%5Clangchain%5Clangchaintest%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=E%3A%5CProjects%5Ctest%5Clangchain%5Clangchaintest&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D! ***!
  \*****************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   headerHooks: () => (/* binding */ headerHooks),\n/* harmony export */   originalPathname: () => (/* binding */ originalPathname),\n/* harmony export */   patchFetch: () => (/* binding */ patchFetch),\n/* harmony export */   requestAsyncStorage: () => (/* binding */ requestAsyncStorage),\n/* harmony export */   routeModule: () => (/* binding */ routeModule),\n/* harmony export */   serverHooks: () => (/* binding */ serverHooks),\n/* harmony export */   staticGenerationAsyncStorage: () => (/* binding */ staticGenerationAsyncStorage),\n/* harmony export */   staticGenerationBailout: () => (/* binding */ staticGenerationBailout)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/app-route/module.compiled */ \"(rsc)/./node_modules/next/dist/server/future/route-modules/app-route/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(rsc)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/server/lib/patch-fetch */ \"(rsc)/./node_modules/next/dist/server/lib/patch-fetch.js\");\n/* harmony import */ var next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var E_Projects_test_langchain_langchaintest_src_app_api_translate_route_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/app/api/translate/route.js */ \"(rsc)/./src/app/api/translate/route.js\");\n\n\n\n\n// We inject the nextConfigOutput here so that we can use them in the route\n// module.\nconst nextConfigOutput = \"\"\nconst routeModule = new next_dist_server_future_route_modules_app_route_module_compiled__WEBPACK_IMPORTED_MODULE_0__.AppRouteRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.APP_ROUTE,\n        page: \"/api/translate/route\",\n        pathname: \"/api/translate\",\n        filename: \"route\",\n        bundlePath: \"app/api/translate/route\"\n    },\n    resolvedPagePath: \"E:\\\\Projects\\\\test\\\\langchain\\\\langchaintest\\\\src\\\\app\\\\api\\\\translate\\\\route.js\",\n    nextConfigOutput,\n    userland: E_Projects_test_langchain_langchaintest_src_app_api_translate_route_js__WEBPACK_IMPORTED_MODULE_3__\n});\n// Pull out the exports that we need to expose from the module. This should\n// be eliminated when we've moved the other routes to the new format. These\n// are used to hook into the route.\nconst { requestAsyncStorage, staticGenerationAsyncStorage, serverHooks, headerHooks, staticGenerationBailout } = routeModule;\nconst originalPathname = \"/api/translate/route\";\nfunction patchFetch() {\n    return (0,next_dist_server_lib_patch_fetch__WEBPACK_IMPORTED_MODULE_2__.patchFetch)({\n        serverHooks,\n        staticGenerationAsyncStorage\n    });\n}\n\n\n//# sourceMappingURL=app-route.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LWFwcC1sb2FkZXIuanM/bmFtZT1hcHAlMkZhcGklMkZ0cmFuc2xhdGUlMkZyb3V0ZSZwYWdlPSUyRmFwaSUyRnRyYW5zbGF0ZSUyRnJvdXRlJmFwcFBhdGhzPSZwYWdlUGF0aD1wcml2YXRlLW5leHQtYXBwLWRpciUyRmFwaSUyRnRyYW5zbGF0ZSUyRnJvdXRlLmpzJmFwcERpcj1FJTNBJTVDUHJvamVjdHMlNUN0ZXN0JTVDbGFuZ2NoYWluJTVDbGFuZ2NoYWludGVzdCU1Q3NyYyU1Q2FwcCZwYWdlRXh0ZW5zaW9ucz10c3gmcGFnZUV4dGVuc2lvbnM9dHMmcGFnZUV4dGVuc2lvbnM9anN4JnBhZ2VFeHRlbnNpb25zPWpzJnJvb3REaXI9RSUzQSU1Q1Byb2plY3RzJTVDdGVzdCU1Q2xhbmdjaGFpbiU1Q2xhbmdjaGFpbnRlc3QmaXNEZXY9dHJ1ZSZ0c2NvbmZpZ1BhdGg9dHNjb25maWcuanNvbiZiYXNlUGF0aD0mYXNzZXRQcmVmaXg9Jm5leHRDb25maWdPdXRwdXQ9JnByZWZlcnJlZFJlZ2lvbj0mbWlkZGxld2FyZUNvbmZpZz1lMzAlM0QhIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQXNHO0FBQ3ZDO0FBQ2M7QUFDZ0M7QUFDN0c7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGdIQUFtQjtBQUMzQztBQUNBLGNBQWMseUVBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLFlBQVk7QUFDWixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsUUFBUSx1R0FBdUc7QUFDL0c7QUFDQTtBQUNBLFdBQVcsNEVBQVc7QUFDdEI7QUFDQTtBQUNBLEtBQUs7QUFDTDtBQUM2Sjs7QUFFN0oiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYW5nY2hhaW50ZXN0Lz8xZjk2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFwcFJvdXRlUm91dGVNb2R1bGUgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUtbW9kdWxlcy9hcHAtcm91dGUvbW9kdWxlLmNvbXBpbGVkXCI7XG5pbXBvcnQgeyBSb3V0ZUtpbmQgfSBmcm9tIFwibmV4dC9kaXN0L3NlcnZlci9mdXR1cmUvcm91dGUta2luZFwiO1xuaW1wb3J0IHsgcGF0Y2hGZXRjaCBhcyBfcGF0Y2hGZXRjaCB9IGZyb20gXCJuZXh0L2Rpc3Qvc2VydmVyL2xpYi9wYXRjaC1mZXRjaFwiO1xuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIkU6XFxcXFByb2plY3RzXFxcXHRlc3RcXFxcbGFuZ2NoYWluXFxcXGxhbmdjaGFpbnRlc3RcXFxcc3JjXFxcXGFwcFxcXFxhcGlcXFxcdHJhbnNsYXRlXFxcXHJvdXRlLmpzXCI7XG4vLyBXZSBpbmplY3QgdGhlIG5leHRDb25maWdPdXRwdXQgaGVyZSBzbyB0aGF0IHdlIGNhbiB1c2UgdGhlbSBpbiB0aGUgcm91dGVcbi8vIG1vZHVsZS5cbmNvbnN0IG5leHRDb25maWdPdXRwdXQgPSBcIlwiXG5jb25zdCByb3V0ZU1vZHVsZSA9IG5ldyBBcHBSb3V0ZVJvdXRlTW9kdWxlKHtcbiAgICBkZWZpbml0aW9uOiB7XG4gICAgICAgIGtpbmQ6IFJvdXRlS2luZC5BUFBfUk9VVEUsXG4gICAgICAgIHBhZ2U6IFwiL2FwaS90cmFuc2xhdGUvcm91dGVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS90cmFuc2xhdGVcIixcbiAgICAgICAgZmlsZW5hbWU6IFwicm91dGVcIixcbiAgICAgICAgYnVuZGxlUGF0aDogXCJhcHAvYXBpL3RyYW5zbGF0ZS9yb3V0ZVwiXG4gICAgfSxcbiAgICByZXNvbHZlZFBhZ2VQYXRoOiBcIkU6XFxcXFByb2plY3RzXFxcXHRlc3RcXFxcbGFuZ2NoYWluXFxcXGxhbmdjaGFpbnRlc3RcXFxcc3JjXFxcXGFwcFxcXFxhcGlcXFxcdHJhbnNsYXRlXFxcXHJvdXRlLmpzXCIsXG4gICAgbmV4dENvbmZpZ091dHB1dCxcbiAgICB1c2VybGFuZFxufSk7XG4vLyBQdWxsIG91dCB0aGUgZXhwb3J0cyB0aGF0IHdlIG5lZWQgdG8gZXhwb3NlIGZyb20gdGhlIG1vZHVsZS4gVGhpcyBzaG91bGRcbi8vIGJlIGVsaW1pbmF0ZWQgd2hlbiB3ZSd2ZSBtb3ZlZCB0aGUgb3RoZXIgcm91dGVzIHRvIHRoZSBuZXcgZm9ybWF0LiBUaGVzZVxuLy8gYXJlIHVzZWQgdG8gaG9vayBpbnRvIHRoZSByb3V0ZS5cbmNvbnN0IHsgcmVxdWVzdEFzeW5jU3RvcmFnZSwgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZSwgc2VydmVySG9va3MsIGhlYWRlckhvb2tzLCBzdGF0aWNHZW5lcmF0aW9uQmFpbG91dCB9ID0gcm91dGVNb2R1bGU7XG5jb25zdCBvcmlnaW5hbFBhdGhuYW1lID0gXCIvYXBpL3RyYW5zbGF0ZS9yb3V0ZVwiO1xuZnVuY3Rpb24gcGF0Y2hGZXRjaCgpIHtcbiAgICByZXR1cm4gX3BhdGNoRmV0Y2goe1xuICAgICAgICBzZXJ2ZXJIb29rcyxcbiAgICAgICAgc3RhdGljR2VuZXJhdGlvbkFzeW5jU3RvcmFnZVxuICAgIH0pO1xufVxuZXhwb3J0IHsgcm91dGVNb2R1bGUsIHJlcXVlc3RBc3luY1N0b3JhZ2UsIHN0YXRpY0dlbmVyYXRpb25Bc3luY1N0b3JhZ2UsIHNlcnZlckhvb2tzLCBoZWFkZXJIb29rcywgc3RhdGljR2VuZXJhdGlvbkJhaWxvdXQsIG9yaWdpbmFsUGF0aG5hbWUsIHBhdGNoRmV0Y2gsICB9O1xuXG4vLyMgc291cmNlTWFwcGluZ1VSTD1hcHAtcm91dGUuanMubWFwIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Ftranslate%2Froute&page=%2Fapi%2Ftranslate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Ftranslate%2Froute.js&appDir=E%3A%5CProjects%5Ctest%5Clangchain%5Clangchaintest%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=E%3A%5CProjects%5Ctest%5Clangchain%5Clangchaintest&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!\n");

/***/ }),

/***/ "(rsc)/./src/app/api/translate/route.js":
/*!****************************************!*\
  !*** ./src/app/api/translate/route.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   GET: () => (/* binding */ GET)\n/* harmony export */ });\n/* harmony import */ var _aws_sdk_client_s3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/client-s3 */ \"@aws-sdk/client-s3\");\n/* harmony import */ var _aws_sdk_client_s3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_aws_sdk_client_s3__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _lib_r2__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/lib/r2 */ \"(rsc)/./src/lib/r2.js\");\n/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chalk */ \"(rsc)/./node_modules/chalk/source/index.js\");\n/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _langchain_openai__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @langchain/openai */ \"(rsc)/./node_modules/@langchain/openai/index.js\");\n/* harmony import */ var _langchain_core_messages__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @langchain/core/messages */ \"(rsc)/./node_modules/@langchain/core/messages.js\");\n\n\n\nconst cheerio = __webpack_require__(/*! cheerio */ \"(rsc)/./node_modules/cheerio/lib/index.js\");\nconst fs = __webpack_require__(/*! fs */ \"fs\");\nconst { PromptTemplate } = __webpack_require__(/*! @langchain/core/prompts */ \"(rsc)/./node_modules/@langchain/core/prompts.cjs\");\n\n\n//const inquirer = require(\"inquirer\");\nconst model = new _langchain_openai__WEBPACK_IMPORTED_MODULE_3__.ChatOpenAI({\n    //   openAIApiKey: process.env.OPENAI_API_KEY,\n    temperature: 0,\n    modelName: \"gpt-3.5-turbo\"\n});\nasync function handlePrompt(input, promptTemplate) {\n    console.log(\"this is handleprompt function\");\n    const promptInput = await promptTemplate.format({\n        question: input\n    });\n    console.log(\"this is prompt input\");\n    console.log(promptInput);\n    try {\n        //return await model.invoke(promptInput);\n        const response = await model.invoke(\"Hi there!\");\n        console.log(\"this is prompt response\");\n        console.log(response);\n    } catch (err) {\n        console.error(err);\n        return null;\n    }\n}\nasync function translate(sourceLanguage, targetLanguage, text) {\n    console.log(\"this is translate function\");\n    const promptTemplate = new PromptTemplate({\n        template: `I am an expert translator. My goal is to provide the best translation possible.\\n\r\n        Translate the following text from ${sourceLanguage} to ${targetLanguage}: \"${text}\"`,\n        inputVariables: [\n            \"question\"\n        ]\n    });\n    return await handlePrompt(text, promptTemplate);\n}\nasync function GET() {\n    try {\n        const response = await translate(\"English\", \"Chinese\", \"I am a student\");\n        console.log(\"This is response from translation\");\n        console.log(response);\n        return new Response({}, {\n            headers: {\n                \"Content-Type\": \"text/html\"\n            }\n        });\n    } catch (err) {\n        console.log(\"there is an error\");\n        console.log(\"error\", err);\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvYXBwL2FwaS90cmFuc2xhdGUvcm91dGUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBc0Q7QUFDeEI7QUFDSjtBQUUxQixNQUFNRyxVQUFVQyxtQkFBT0EsQ0FBQywwREFBUztBQUNqQyxNQUFNQyxLQUFLRCxtQkFBT0EsQ0FBQyxjQUFJO0FBQ3ZCLE1BQU0sRUFBRUUsY0FBYyxFQUFFLEdBQUdGLG1CQUFPQSxDQUFDLGlGQUF5QjtBQUNiO0FBQ1M7QUFFeEQsdUNBQXVDO0FBRXZDLE1BQU1LLFFBQVEsSUFBSUYseURBQVVBLENBQUM7SUFDM0IsOENBQThDO0lBQzlDRyxhQUFhO0lBQ2JDLFdBQVc7QUFDYjtBQUVBLGVBQWVDLGFBQWFDLEtBQUssRUFBRUMsY0FBYztJQUMvQ0MsUUFBUUMsR0FBRyxDQUFDO0lBQ1osTUFBTUMsY0FBYyxNQUFNSCxlQUFlSSxNQUFNLENBQUM7UUFDOUNDLFVBQVVOO0lBQ1o7SUFFQUUsUUFBUUMsR0FBRyxDQUFDO0lBQ1pELFFBQVFDLEdBQUcsQ0FBQ0M7SUFFWixJQUFJO1FBQ0YseUNBQXlDO1FBQ3pDLE1BQU1HLFdBQVcsTUFBTVgsTUFBTVksTUFBTSxDQUFDO1FBQ3BDTixRQUFRQyxHQUFHLENBQUM7UUFDWkQsUUFBUUMsR0FBRyxDQUFDSTtJQUNkLEVBQUUsT0FBT0UsS0FBSztRQUNaUCxRQUFRUSxLQUFLLENBQUNEO1FBQ2QsT0FBTztJQUNUO0FBQ0Y7QUFFQSxlQUFlRSxVQUFVQyxjQUFjLEVBQUVDLGNBQWMsRUFBRUMsSUFBSTtJQUMzRFosUUFBUUMsR0FBRyxDQUFDO0lBQ1osTUFBTUYsaUJBQWlCLElBQUlSLGVBQWU7UUFDeENzQixVQUFVLENBQUM7MENBQzJCLEVBQUVILGVBQWUsSUFBSSxFQUFFQyxlQUFlLEdBQUcsRUFBRUMsS0FBSyxDQUFDLENBQUM7UUFDeEZFLGdCQUFnQjtZQUFDO1NBQVc7SUFDOUI7SUFFQSxPQUFPLE1BQU1qQixhQUFhZSxNQUFNYjtBQUNsQztBQUVPLGVBQWVnQjtJQUNwQixJQUFJO1FBQ0YsTUFBTVYsV0FBVyxNQUFNSSxVQUFVLFdBQVcsV0FBVztRQUN2RFQsUUFBUUMsR0FBRyxDQUFDO1FBQ1pELFFBQVFDLEdBQUcsQ0FBQ0k7UUFDWixPQUFPLElBQUlXLFNBQ1QsQ0FBQyxHQUNEO1lBQ0VDLFNBQVM7Z0JBQ1AsZ0JBQWdCO1lBQ2xCO1FBQ0Y7SUFFSixFQUFFLE9BQU9WLEtBQUs7UUFDWlAsUUFBUUMsR0FBRyxDQUFDO1FBQ1pELFFBQVFDLEdBQUcsQ0FBQyxTQUFTTTtJQUN2QjtBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vbGFuZ2NoYWludGVzdC8uL3NyYy9hcHAvYXBpL3RyYW5zbGF0ZS9yb3V0ZS5qcz81NGZmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEdldE9iamVjdENvbW1hbmQgfSBmcm9tIFwiQGF3cy1zZGsvY2xpZW50LXMzXCI7XHJcbmltcG9ydCB7IHIyIH0gZnJvbSBcIkAvbGliL3IyXCI7XHJcbmltcG9ydCBjaGFsayBmcm9tIFwiY2hhbGtcIjtcclxuXHJcbmNvbnN0IGNoZWVyaW8gPSByZXF1aXJlKFwiY2hlZXJpb1wiKTtcclxuY29uc3QgZnMgPSByZXF1aXJlKFwiZnNcIik7XHJcbmNvbnN0IHsgUHJvbXB0VGVtcGxhdGUgfSA9IHJlcXVpcmUoXCJAbGFuZ2NoYWluL2NvcmUvcHJvbXB0c1wiKTtcclxuaW1wb3J0IHsgQ2hhdE9wZW5BSSB9IGZyb20gXCJAbGFuZ2NoYWluL29wZW5haVwiO1xyXG5pbXBvcnQgeyBIdW1hbk1lc3NhZ2UgfSBmcm9tIFwiQGxhbmdjaGFpbi9jb3JlL21lc3NhZ2VzXCI7XHJcblxyXG4vL2NvbnN0IGlucXVpcmVyID0gcmVxdWlyZShcImlucXVpcmVyXCIpO1xyXG5cclxuY29uc3QgbW9kZWwgPSBuZXcgQ2hhdE9wZW5BSSh7XHJcbiAgLy8gICBvcGVuQUlBcGlLZXk6IHByb2Nlc3MuZW52Lk9QRU5BSV9BUElfS0VZLFxyXG4gIHRlbXBlcmF0dXJlOiAwLFxyXG4gIG1vZGVsTmFtZTogXCJncHQtMy41LXR1cmJvXCIsXHJcbn0pO1xyXG5cclxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlUHJvbXB0KGlucHV0LCBwcm9tcHRUZW1wbGF0ZSkge1xyXG4gIGNvbnNvbGUubG9nKFwidGhpcyBpcyBoYW5kbGVwcm9tcHQgZnVuY3Rpb25cIik7XHJcbiAgY29uc3QgcHJvbXB0SW5wdXQgPSBhd2FpdCBwcm9tcHRUZW1wbGF0ZS5mb3JtYXQoe1xyXG4gICAgcXVlc3Rpb246IGlucHV0LFxyXG4gIH0pO1xyXG5cclxuICBjb25zb2xlLmxvZyhcInRoaXMgaXMgcHJvbXB0IGlucHV0XCIpO1xyXG4gIGNvbnNvbGUubG9nKHByb21wdElucHV0KTtcclxuXHJcbiAgdHJ5IHtcclxuICAgIC8vcmV0dXJuIGF3YWl0IG1vZGVsLmludm9rZShwcm9tcHRJbnB1dCk7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IG1vZGVsLmludm9rZShcIkhpIHRoZXJlIVwiKTtcclxuICAgIGNvbnNvbGUubG9nKFwidGhpcyBpcyBwcm9tcHQgcmVzcG9uc2VcIik7XHJcbiAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycik7XHJcbiAgICByZXR1cm4gbnVsbDtcclxuICB9XHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHRyYW5zbGF0ZShzb3VyY2VMYW5ndWFnZSwgdGFyZ2V0TGFuZ3VhZ2UsIHRleHQpIHtcclxuICBjb25zb2xlLmxvZyhcInRoaXMgaXMgdHJhbnNsYXRlIGZ1bmN0aW9uXCIpO1xyXG4gIGNvbnN0IHByb21wdFRlbXBsYXRlID0gbmV3IFByb21wdFRlbXBsYXRlKHtcclxuICAgIHRlbXBsYXRlOiBgSSBhbSBhbiBleHBlcnQgdHJhbnNsYXRvci4gTXkgZ29hbCBpcyB0byBwcm92aWRlIHRoZSBiZXN0IHRyYW5zbGF0aW9uIHBvc3NpYmxlLlxcblxyXG4gICAgICAgIFRyYW5zbGF0ZSB0aGUgZm9sbG93aW5nIHRleHQgZnJvbSAke3NvdXJjZUxhbmd1YWdlfSB0byAke3RhcmdldExhbmd1YWdlfTogXCIke3RleHR9XCJgLFxyXG4gICAgaW5wdXRWYXJpYWJsZXM6IFtcInF1ZXN0aW9uXCJdLFxyXG4gIH0pO1xyXG5cclxuICByZXR1cm4gYXdhaXQgaGFuZGxlUHJvbXB0KHRleHQsIHByb21wdFRlbXBsYXRlKTtcclxufVxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIEdFVCgpIHtcclxuICB0cnkge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0cmFuc2xhdGUoXCJFbmdsaXNoXCIsIFwiQ2hpbmVzZVwiLCBcIkkgYW0gYSBzdHVkZW50XCIpO1xyXG4gICAgY29uc29sZS5sb2coXCJUaGlzIGlzIHJlc3BvbnNlIGZyb20gdHJhbnNsYXRpb25cIik7XHJcbiAgICBjb25zb2xlLmxvZyhyZXNwb25zZSk7XHJcbiAgICByZXR1cm4gbmV3IFJlc3BvbnNlKFxyXG4gICAgICB7fSxcclxuICAgICAge1xyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwidGV4dC9odG1sXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgfVxyXG4gICAgKTtcclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKFwidGhlcmUgaXMgYW4gZXJyb3JcIik7XHJcbiAgICBjb25zb2xlLmxvZyhcImVycm9yXCIsIGVycik7XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJHZXRPYmplY3RDb21tYW5kIiwicjIiLCJjaGFsayIsImNoZWVyaW8iLCJyZXF1aXJlIiwiZnMiLCJQcm9tcHRUZW1wbGF0ZSIsIkNoYXRPcGVuQUkiLCJIdW1hbk1lc3NhZ2UiLCJtb2RlbCIsInRlbXBlcmF0dXJlIiwibW9kZWxOYW1lIiwiaGFuZGxlUHJvbXB0IiwiaW5wdXQiLCJwcm9tcHRUZW1wbGF0ZSIsImNvbnNvbGUiLCJsb2ciLCJwcm9tcHRJbnB1dCIsImZvcm1hdCIsInF1ZXN0aW9uIiwicmVzcG9uc2UiLCJpbnZva2UiLCJlcnIiLCJlcnJvciIsInRyYW5zbGF0ZSIsInNvdXJjZUxhbmd1YWdlIiwidGFyZ2V0TGFuZ3VhZ2UiLCJ0ZXh0IiwidGVtcGxhdGUiLCJpbnB1dFZhcmlhYmxlcyIsIkdFVCIsIlJlc3BvbnNlIiwiaGVhZGVycyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(rsc)/./src/app/api/translate/route.js\n");

/***/ }),

/***/ "(rsc)/./src/lib/r2.js":
/*!***********************!*\
  !*** ./src/lib/r2.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   r2: () => (/* binding */ r2)\n/* harmony export */ });\n/* harmony import */ var _aws_sdk_client_s3__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @aws-sdk/client-s3 */ \"@aws-sdk/client-s3\");\n/* harmony import */ var _aws_sdk_client_s3__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_aws_sdk_client_s3__WEBPACK_IMPORTED_MODULE_0__);\n\nconst r2 = new _aws_sdk_client_s3__WEBPACK_IMPORTED_MODULE_0__.S3Client({\n    region: \"auto\",\n    endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,\n    credentials: {\n        accessKeyId: process.env.R2_ACCESS_KEY_ID || \"\",\n        secretAccessKey: process.env.R2_SECRET_ACCESS_KEY || \"\"\n    }\n});\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9zcmMvbGliL3IyLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUE4QztBQUV2QyxNQUFNQyxLQUFLLElBQUlELHdEQUFRQSxDQUFDO0lBQzdCRSxRQUFRO0lBQ1JDLFVBQVUsQ0FBQyxRQUFRLEVBQUVDLFFBQVFDLEdBQUcsQ0FBQ0MsYUFBYSxDQUFDLHlCQUF5QixDQUFDO0lBQ3pFQyxhQUFhO1FBQ1hDLGFBQWFKLFFBQVFDLEdBQUcsQ0FBQ0ksZ0JBQWdCLElBQUk7UUFDN0NDLGlCQUFpQk4sUUFBUUMsR0FBRyxDQUFDTSxvQkFBb0IsSUFBSTtJQUN2RDtBQUNGLEdBQUciLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYW5nY2hhaW50ZXN0Ly4vc3JjL2xpYi9yMi5qcz80N2JmIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFMzQ2xpZW50IH0gZnJvbSBcIkBhd3Mtc2RrL2NsaWVudC1zM1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IHIyID0gbmV3IFMzQ2xpZW50KHtcclxuICByZWdpb246IFwiYXV0b1wiLFxyXG4gIGVuZHBvaW50OiBgaHR0cHM6Ly8ke3Byb2Nlc3MuZW52LlIyX0FDQ09VTlRfSUR9LnIyLmNsb3VkZmxhcmVzdG9yYWdlLmNvbWAsXHJcbiAgY3JlZGVudGlhbHM6IHtcclxuICAgIGFjY2Vzc0tleUlkOiBwcm9jZXNzLmVudi5SMl9BQ0NFU1NfS0VZX0lEIHx8IFwiXCIsXHJcbiAgICBzZWNyZXRBY2Nlc3NLZXk6IHByb2Nlc3MuZW52LlIyX1NFQ1JFVF9BQ0NFU1NfS0VZIHx8IFwiXCIsXHJcbiAgfSxcclxufSk7XHJcbiJdLCJuYW1lcyI6WyJTM0NsaWVudCIsInIyIiwicmVnaW9uIiwiZW5kcG9pbnQiLCJwcm9jZXNzIiwiZW52IiwiUjJfQUNDT1VOVF9JRCIsImNyZWRlbnRpYWxzIiwiYWNjZXNzS2V5SWQiLCJSMl9BQ0NFU1NfS0VZX0lEIiwic2VjcmV0QWNjZXNzS2V5IiwiUjJfU0VDUkVUX0FDQ0VTU19LRVkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(rsc)/./src/lib/r2.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next","vendor-chunks/formdata-node","vendor-chunks/@swc","vendor-chunks/@langchain","vendor-chunks/openai","vendor-chunks/zod-to-json-schema","vendor-chunks/uuid","vendor-chunks/parse5","vendor-chunks/langsmith","vendor-chunks/cheerio","vendor-chunks/form-data-encoder","vendor-chunks/css-select","vendor-chunks/entities","vendor-chunks/domutils","vendor-chunks/whatwg-url","vendor-chunks/css-what","vendor-chunks/agentkeepalive","vendor-chunks/retry","vendor-chunks/p-queue","vendor-chunks/nth-check","vendor-chunks/htmlparser2","vendor-chunks/color-convert","vendor-chunks/cheerio-select","vendor-chunks/chalk","vendor-chunks/js-tiktoken","vendor-chunks/tr46","vendor-chunks/domhandler","vendor-chunks/dom-serializer","vendor-chunks/zod","vendor-chunks/node-fetch","vendor-chunks/parse5-htmlparser2-tree-adapter","vendor-chunks/webidl-conversions","vendor-chunks/web-streams-polyfill","vendor-chunks/supports-color","vendor-chunks/p-timeout","vendor-chunks/p-retry","vendor-chunks/p-finally","vendor-chunks/ms","vendor-chunks/humanize-ms","vendor-chunks/has-flag","vendor-chunks/eventemitter3","vendor-chunks/event-target-shim","vendor-chunks/domelementtype","vendor-chunks/decamelize","vendor-chunks/color-name","vendor-chunks/camelcase","vendor-chunks/boolbase","vendor-chunks/base64-js","vendor-chunks/ansi-styles","vendor-chunks/abort-controller"], () => (__webpack_exec__("(rsc)/./node_modules/next/dist/build/webpack/loaders/next-app-loader.js?name=app%2Fapi%2Ftranslate%2Froute&page=%2Fapi%2Ftranslate%2Froute&appPaths=&pagePath=private-next-app-dir%2Fapi%2Ftranslate%2Froute.js&appDir=E%3A%5CProjects%5Ctest%5Clangchain%5Clangchaintest%5Csrc%5Capp&pageExtensions=tsx&pageExtensions=ts&pageExtensions=jsx&pageExtensions=js&rootDir=E%3A%5CProjects%5Ctest%5Clangchain%5Clangchaintest&isDev=true&tsconfigPath=tsconfig.json&basePath=&assetPrefix=&nextConfigOutput=&preferredRegion=&middlewareConfig=e30%3D!")));
module.exports = __webpack_exports__;

})();