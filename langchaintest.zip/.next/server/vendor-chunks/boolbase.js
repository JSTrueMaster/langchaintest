"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
exports.id = "vendor-chunks/boolbase";
exports.ids = ["vendor-chunks/boolbase"];
exports.modules = {

/***/ "(rsc)/./node_modules/boolbase/index.js":
/*!****************************************!*\
  !*** ./node_modules/boolbase/index.js ***!
  \****************************************/
/***/ ((module) => {

eval("\nmodule.exports = {\n    trueFunc: function trueFunc() {\n        return true;\n    },\n    falseFunc: function falseFunc() {\n        return false;\n    }\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKHJzYykvLi9ub2RlX21vZHVsZXMvYm9vbGJhc2UvaW5kZXguanMiLCJtYXBwaW5ncyI6IjtBQUFBQSxPQUFPQyxPQUFPLEdBQUc7SUFDaEJDLFVBQVUsU0FBU0E7UUFDbEIsT0FBTztJQUNSO0lBQ0FDLFdBQVcsU0FBU0E7UUFDbkIsT0FBTztJQUNSO0FBQ0QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9sYW5nY2hhaW50ZXN0Ly4vbm9kZV9tb2R1bGVzL2Jvb2xiYXNlL2luZGV4LmpzPzU0NzkiXSwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPSB7XG5cdHRydWVGdW5jOiBmdW5jdGlvbiB0cnVlRnVuYygpe1xuXHRcdHJldHVybiB0cnVlO1xuXHR9LFxuXHRmYWxzZUZ1bmM6IGZ1bmN0aW9uIGZhbHNlRnVuYygpe1xuXHRcdHJldHVybiBmYWxzZTtcblx0fVxufTsiXSwibmFtZXMiOlsibW9kdWxlIiwiZXhwb3J0cyIsInRydWVGdW5jIiwiZmFsc2VGdW5jIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(rsc)/./node_modules/boolbase/index.js\n");

/***/ })

};
;